package com.example.gameblaze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameblazeApplicationTests {

	@Test
	void contextLoads() {
	}

}
