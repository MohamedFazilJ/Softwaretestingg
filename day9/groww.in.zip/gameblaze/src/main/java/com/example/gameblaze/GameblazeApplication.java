package com.example.gameblaze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameblazeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameblazeApplication.class, args);
	}

}
